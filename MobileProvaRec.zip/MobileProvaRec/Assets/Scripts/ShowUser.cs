using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ShowUser : MonoBehaviour
{
    public TMP_Text txtuser;
    public TMP_Text txtsenha;

    void Start()
    {
        txtuser.text = PlayerPrefs.GetString("username");
        txtsenha.text = PlayerPrefs.GetString("password");
    }


    void Update()
    {
        
    }
}
