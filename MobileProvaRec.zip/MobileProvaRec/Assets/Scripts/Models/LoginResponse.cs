using System;
using UnityEngine;

namespace Assets.Scripts.Models
{
    [Serializable]
    public class LoginResponse
    {
        [SerializeField]
        public string token;
    }
}