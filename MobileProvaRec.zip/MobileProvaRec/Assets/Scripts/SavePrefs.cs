using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SavePrefs : MonoBehaviour
{
    public TMP_InputField txtUsuario;
    public TMP_InputField txtSenha;

    void Start()
    {
        LoadPrefs();
    }

    public void SavePref()
    {
        PlayerPrefs.SetString("username", txtUsuario.text);
        PlayerPrefs.SetString("password", txtSenha.text);

        ChangeScene();
    }

    private void LoadPrefs()
    {
        txtUsuario.text = PlayerPrefs.GetString("username");
        txtSenha.text = PlayerPrefs.GetString("password");
    }

    private void ChangeScene()
    {
        SceneManager.LoadScene("PrincipalScene");
    }

}